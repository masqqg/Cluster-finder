package com.example.addon.modules;

import com.example.addon.ClusterFinderAddon;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongArrayList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.BlockListSetting;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.ColorSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.network.MeteorExecutor;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.Color;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Groups the chosen blocks of every loaded chunk into connected clusters, remembers how big each cluster was the
 * last time it was seen (so growth can be detected), draws tracers to the interesting ones and highlights chunks
 * that contain several big clusters.
 *
 * Note: this can only work with the blocks the server actually sends. If the server hides something behind a
 * different block, that block is all the client ever sees, so the module clusters what is visible.
 */
public class ClusterFinder extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgGrowth = settings.createGroup("Growth");
    private final SettingGroup sgChunks = settings.createGroup("Chunk Finder");
    private final SettingGroup sgShafts = settings.createGroup("Shaft Finder");
    private final SettingGroup sgEggs = settings.createGroup("Egg Finder");
    private final SettingGroup sgRender = settings.createGroup("Render");

    // General

    private final Setting<List<Block>> blocks = sgGeneral.add(new BlockListSetting.Builder()
        .name("blocks")
        .description("Blocks that make up a cluster.")
        .defaultValue(List.of(Blocks.DEEPSLATE))
        .onChanged(list -> {
            blockSet = new HashSet<>(list);
            rescanAll();
        })
        .build()
    );

    private final Setting<Integer> minY = sgGeneral.add(new IntSetting.Builder()
        .name("min-y")
        .description("Lowest Y level to look at. Vanilla deepslate only generates below about Y 8, so deepslate above that is unusual.")
        .defaultValue(9)
        .range(-64, 320)
        .sliderRange(-64, 128)
        .onChanged(v -> rescanAll())
        .build()
    );

    private final Setting<Integer> maxY = sgGeneral.add(new IntSetting.Builder()
        .name("max-y")
        .description("Highest Y level to look at.")
        .defaultValue(320)
        .range(-64, 320)
        .sliderRange(-64, 320)
        .onChanged(v -> rescanAll())
        .build()
    );

    private final Setting<Integer> gap = sgGeneral.add(new IntSetting.Builder()
        .name("cluster-gap")
        .description("Blocks closer than this (in blocks, per axis) count as the same cluster. 1 means touching.")
        .defaultValue(1)
        .range(1, 3)
        .sliderRange(1, 3)
        .onChanged(v -> dirty = true)
        .build()
    );

    private final Setting<Integer> minClusterSize = sgGeneral.add(new IntSetting.Builder()
        .name("min-cluster-size")
        .description("Clusters smaller than this are ignored.")
        .defaultValue(12)
        .range(3, 5000)
        .sliderRange(3, 200)
        .build()
    );

    private final Setting<Integer> maxClusterSize = sgGeneral.add(new IntSetting.Builder()
        .name("max-cluster-size")
        .description("Clusters bigger than this are ignored, which filters out huge natural masses.")
        .defaultValue(2000)
        .range(10, 200000)
        .sliderRange(100, 20000)
        .build()
    );

    private final Setting<Integer> maxBlocksPerChunk = sgGeneral.add(new IntSetting.Builder()
        .name("max-blocks-per-chunk")
        .description("Chunks with more matching blocks than this are skipped, because they are almost certainly natural terrain.")
        .defaultValue(3000)
        .range(16, 65536)
        .sliderRange(100, 10000)
        .onChanged(v -> rescanAll())
        .build()
    );

    private final Setting<Integer> maxTotalBlocks = sgGeneral.add(new IntSetting.Builder()
        .name("max-total-blocks")
        .description("Safety cap on how many blocks are kept in memory. New chunks are skipped once it is reached.")
        .defaultValue(300000)
        .range(1000, 5000000)
        .sliderRange(10000, 1000000)
        .build()
    );

    private final Setting<Integer> updateInterval = sgGeneral.add(new IntSetting.Builder()
        .name("update-interval")
        .description("How many ticks to wait between refreshing the clusters.")
        .defaultValue(20)
        .range(5, 200)
        .sliderRange(5, 100)
        .build()
    );

    // Growth

    private final Setting<Boolean> growingOnly = sgGrowth.add(new BoolSetting.Builder()
        .name("growing-only")
        .description("Only draw tracers to clusters that have grown recently.")
        .defaultValue(false)
        .build()
    );

    private final Setting<Integer> growthWindow = sgGrowth.add(new IntSetting.Builder()
        .name("growth-window")
        .description("A cluster counts as growing if it got bigger within this many seconds.")
        .defaultValue(120)
        .range(5, 3600)
        .sliderRange(10, 600)
        .build()
    );

    // Chunk finder

    private final Setting<Boolean> chunkFinder = sgChunks.add(new BoolSetting.Builder()
        .name("chunk-finder")
        .description("Marks chunks that contain several big clusters.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> bigClusterSize = sgChunks.add(new IntSetting.Builder()
        .name("big-cluster-size")
        .description("Minimum size for a cluster to count as big.")
        .defaultValue(30)
        .range(3, 5000)
        .sliderRange(10, 300)
        .visible(chunkFinder::get)
        .build()
    );

    private final Setting<Integer> chunkClusterCount = sgChunks.add(new IntSetting.Builder()
        .name("clusters-per-chunk")
        .description("How many big clusters a chunk needs to be marked.")
        .defaultValue(5)
        .range(1, 64)
        .sliderRange(1, 20)
        .visible(chunkFinder::get)
        .build()
    );

    private final Setting<Boolean> chunkNotifications = sgChunks.add(new BoolSetting.Builder()
        .name("notifications")
        .description("Sends a chat message when a new chunk gets marked.")
        .defaultValue(true)
        .visible(chunkFinder::get)
        .build()
    );

    // Shaft finder

    private final Setting<Boolean> shaftFinder = sgShafts.add(new BoolSetting.Builder()
        .name("shaft-finder")
        .description("Marks chunks that have a shaft dug straight down and capped with one of the cover blocks.")
        .defaultValue(true)
        .onChanged(v -> rescanAll())
        .build()
    );

    private final Setting<List<Block>> coverBlocks = sgShafts.add(new BlockListSetting.Builder()
        .name("cover-blocks")
        .description("Blocks used to cap a shaft: cracked stone bricks, cracked deepslate bricks and end stone by default.")
        .defaultValue(List.of(Blocks.CRACKED_STONE_BRICKS, Blocks.CRACKED_DEEPSLATE_BRICKS, Blocks.END_STONE))
        .onChanged(list -> {
            coverSet = new HashSet<>(list);
            rescanAll();
        })
        .visible(shaftFinder::get)
        .build()
    );

    private final Setting<Integer> minShaftDepth = sgShafts.add(new IntSetting.Builder()
        .name("min-shaft-depth")
        .description("How many air blocks must be straight below the cover block for it to count as a shaft.")
        .defaultValue(8)
        .range(2, 300)
        .sliderRange(2, 64)
        .onChanged(v -> rescanAll())
        .visible(shaftFinder::get)
        .build()
    );

    private final Setting<Boolean> narrowShafts = sgShafts.add(new BoolSetting.Builder()
        .name("narrow-shafts-only")
        .description("Only count 1x1 shafts, so open caves under a cover block are ignored.")
        .defaultValue(true)
        .onChanged(v -> rescanAll())
        .visible(shaftFinder::get)
        .build()
    );

    // Egg finder

    private final Setting<Boolean> eggFinder = sgEggs.add(new BoolSetting.Builder()
        .name("egg-finder")
        .description("Marks chunks that contain an egg block.")
        .defaultValue(true)
        .onChanged(v -> rescanAll())
        .build()
    );

    private final Setting<List<Block>> eggBlocks = sgEggs.add(new BlockListSetting.Builder()
        .name("egg-blocks")
        .description("Which blocks count as an egg. Dragon egg by default, you can add turtle or sniffer eggs.")
        .defaultValue(List.of(Blocks.DRAGON_EGG))
        .onChanged(list -> {
            eggSet = new HashSet<>(list);
            rescanAll();
        })
        .visible(eggFinder::get)
        .build()
    );

    // Render

    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
        .name("tracers")
        .description("Draws a line from the crosshair to each cluster.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> boxes = sgRender.add(new BoolSetting.Builder()
        .name("cluster-boxes")
        .description("Draws a box around each cluster.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> chunkTracers = sgRender.add(new BoolSetting.Builder()
        .name("chunk-tracers")
        .description("Also draws a tracer to every marked chunk.")
        .defaultValue(true)
        .visible(chunkFinder::get)
        .build()
    );

    private final Setting<Integer> maxTracers = sgRender.add(new IntSetting.Builder()
        .name("max-tracers")
        .description("Maximum number of clusters to draw. The nearest ones are kept.")
        .defaultValue(64)
        .range(1, 1000)
        .sliderRange(8, 256)
        .build()
    );

    private final Setting<Integer> maxDistance = sgRender.add(new IntSetting.Builder()
        .name("max-distance")
        .description("Clusters farther away than this are not drawn.")
        .defaultValue(512)
        .range(16, 5000)
        .sliderRange(64, 2000)
        .build()
    );

    private final Setting<SettingColor> clusterColor = sgRender.add(new ColorSetting.Builder()
        .name("cluster-color")
        .description("Color of clusters that are not growing.")
        .defaultValue(new SettingColor(160, 90, 255, 170))
        .build()
    );

    private final Setting<SettingColor> growingColor = sgRender.add(new ColorSetting.Builder()
        .name("growing-color")
        .description("Color of clusters that are growing.")
        .defaultValue(new SettingColor(255, 70, 70, 220))
        .build()
    );

    private final Setting<SettingColor> chunkColor = sgRender.add(new ColorSetting.Builder()
        .name("chunk-color")
        .description("Color of marked chunks.")
        .defaultValue(new SettingColor(255, 205, 40, 200))
        .visible(chunkFinder::get)
        .build()
    );

    private final Setting<SettingColor> specialColor = sgRender.add(new ColorSetting.Builder()
        .name("shaft-egg-color")
        .description("Color of chunks marked by the shaft finder or the egg finder.")
        .defaultValue(new SettingColor(40, 220, 255, 200))
        .build()
    );

    // State

    private record Cluster(int size, double x, double y, double z,
                           int minX, int minY, int minZ, int maxX, int maxY, int maxZ, long lastGrow) {
        boolean growing(long now, long windowMs) {
            return lastGrow > 0 && now - lastGrow <= windowMs;
        }
    }

    private record Track(int size, long lastGrow) {}

    private record ChunkMark(int cx, int cz, int count, int minY, int maxY) {}

    private record Special(int shafts, int eggs, int minY, int maxY) {}

    private record SpecialMark(int cx, int cz, int shafts, int eggs, int minY, int maxY) {}

    private final Object lock = new Object();
    private final Long2ObjectMap<LongOpenHashSet> chunkBlocks = new Long2ObjectOpenHashMap<>();
    private long totalBlocks;

    private final AtomicBoolean busy = new AtomicBoolean(false);
    private volatile boolean dirty;
    private volatile boolean capHit;
    private boolean capWarned;

    private volatile Set<Block> blockSet = new HashSet<>(List.of(Blocks.DEEPSLATE));
    private volatile Long2ObjectMap<Track> previous = new Long2ObjectOpenHashMap<>();

    private volatile Set<Block> coverSet = new HashSet<>(List.of(Blocks.CRACKED_STONE_BRICKS, Blocks.CRACKED_DEEPSLATE_BRICKS, Blocks.END_STONE));
    private volatile Set<Block> eggSet = new HashSet<>(List.of(Blocks.DRAGON_EGG));
    private final Long2ObjectMap<Special> specials = new Long2ObjectOpenHashMap<>(); // guarded by lock
    private volatile List<SpecialMark> specialMarks = List.of();
    private final LongOpenHashSet announcedSpecial = new LongOpenHashSet();

    private volatile List<Cluster> clusters = List.of();
    private volatile List<Cluster> drawClusters = List.of();
    private volatile List<ChunkMark> marks = List.of();
    private final LongOpenHashSet announced = new LongOpenHashSet();

    private ClientWorld lastWorld;
    private int ticks;

    public ClusterFinder() {
        super(ClusterFinderAddon.CATEGORY, "cluster-finder",
            "Finds clusters of chosen blocks, tracks their growth, draws tracers and marks chunks with several big clusters.");
    }

    @Override
    public void onActivate() {
        blockSet = new HashSet<>(blocks.get());
        coverSet = new HashSet<>(coverBlocks.get());
        eggSet = new HashSet<>(eggBlocks.get());
        reset();
        lastWorld = mc.world;
        rescanAll();
    }

    @Override
    public void onDeactivate() {
        reset();
    }

    private void reset() {
        synchronized (lock) {
            chunkBlocks.clear();
            totalBlocks = 0;
        }

        synchronized (lock) {
            specials.clear();
        }
        specialMarks = List.of();
        announcedSpecial.clear();

        previous = new Long2ObjectOpenHashMap<>();
        clusters = List.of();
        drawClusters = List.of();
        marks = List.of();
        announced.clear();
        capHit = false;
        capWarned = false;
        dirty = false;
    }

    private void rescanAll() {
        if (!isActive() || !Utils.canUpdate()) return;

        synchronized (lock) {
            chunkBlocks.clear();
            totalBlocks = 0;
        }

        synchronized (lock) {
            specials.clear();
        }
        announcedSpecial.clear();

        for (Chunk chunk : Utils.chunks()) {
            scheduleScan(chunk);
        }

        dirty = true;
    }

    private void scheduleScan(Chunk chunk) {
        MeteorExecutor.execute(() -> scanChunk(chunk));
    }

    // Scanning

    private void scanChunk(Chunk chunk) {
        if (!isActive()) return;

        Set<Block> set = blockSet;
        Set<Block> covers = shaftFinder.get() ? coverSet : Set.of();
        Set<Block> eggs = eggFinder.get() ? eggSet : Set.of();
        if (set.isEmpty() && covers.isEmpty() && eggs.isEmpty()) return;

        int lo = minY.get();
        int hi = maxY.get();
        ChunkPos cp = chunk.getPos();
        int startX = cp.getStartX();
        int startZ = cp.getStartZ();

        LongOpenHashSet found = null;
        ChunkSection[] sections = chunk.getSectionArray();

        int bottomY = chunk.getBottomY();
        int topY = bottomY + chunk.getHeight();
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        boolean clusterScan = !set.isEmpty();
        int minDepth = minShaftDepth.get();
        boolean narrow = narrowShafts.get();

        int shafts = 0;
        int eggCount = 0;
        int specialMin = Integer.MAX_VALUE;
        int specialMax = Integer.MIN_VALUE;

        for (int baseY = bottomY; baseY < topY; baseY += 16) {
            int index = chunk.getSectionIndex(baseY);
            if (index < 0 || index >= sections.length) continue;

            ChunkSection section = sections[index];
            if (section == null) continue;

            for (int y = 0; y < 16; y++) {
                int worldY = baseY + y;
                boolean inClusterRange = clusterScan && worldY >= lo && worldY <= hi;

                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        Block block = section.getBlockState(x, y, z).getBlock();

                        if (inClusterRange && set.contains(block)) {
                            if (found == null) found = new LongOpenHashSet();
                            found.add(pack(startX + x, worldY, startZ + z));
                        }

                        if (!covers.isEmpty() && covers.contains(block)) {
                            int depth = shaftDepth(chunk, mutable, startX + x, worldY, startZ + z, bottomY, narrow);

                            if (depth >= minDepth) {
                                shafts++;
                                specialMin = Math.min(specialMin, worldY - depth);
                                specialMax = Math.max(specialMax, worldY);
                            }
                        }

                        if (!eggs.isEmpty() && eggs.contains(block)) {
                            eggCount++;
                            specialMin = Math.min(specialMin, worldY);
                            specialMax = Math.max(specialMax, worldY);
                        }
                    }
                }
            }
        }

        if (found != null && found.size() > maxBlocksPerChunk.get()) found = null;

        long key = cp.toLong();
        synchronized (lock) {
            if (shafts > 0 || eggCount > 0) specials.put(key, new Special(shafts, eggCount, specialMin, specialMax));
            else specials.remove(key);

            LongOpenHashSet old = chunkBlocks.remove(key);
            if (old != null) totalBlocks -= old.size();

            if (found != null) {
                if (totalBlocks + found.size() > maxTotalBlocks.get()) {
                    capHit = true;
                } else {
                    chunkBlocks.put(key, found);
                    totalBlocks += found.size();
                }
            }

            dirty = true;
        }
    }

    /**
     * Counts the air blocks straight below a cover block. With {@code narrow} set, the walls around every counted
     * block must be solid (neighbours that sit in another chunk are not checked), so only 1x1 shafts count.
     */
    private int shaftDepth(Chunk chunk, BlockPos.Mutable pos, int x, int y, int z, int bottomY, boolean narrow) {
        int startX = chunk.getPos().getStartX();
        int startZ = chunk.getPos().getStartZ();
        int depth = 0;

        for (int cy = y - 1; cy >= bottomY; cy--) {
            if (!chunk.getBlockState(pos.set(x, cy, z)).isAir()) break;

            if (narrow) {
                boolean open = false;

                if (x - 1 >= startX && chunk.getBlockState(pos.set(x - 1, cy, z)).isAir()) open = true;
                else if (x + 1 <= startX + 15 && chunk.getBlockState(pos.set(x + 1, cy, z)).isAir()) open = true;
                else if (z - 1 >= startZ && chunk.getBlockState(pos.set(x, cy, z - 1)).isAir()) open = true;
                else if (z + 1 <= startZ + 15 && chunk.getBlockState(pos.set(x, cy, z + 1)).isAir()) open = true;

                if (open) break;
            }

            depth++;
        }

        return depth;
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        scheduleScan(event.chunk());
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        Set<Block> set = blockSet;
        boolean was = set.contains(event.oldState.getBlock());
        boolean is = set.contains(event.newState.getBlock());
        if (was == is) return;

        // The event object is reused by Meteor, so copy what we need.
        int x = event.pos.getX();
        int y = event.pos.getY();
        int z = event.pos.getZ();
        if (y < minY.get() || y > maxY.get()) return;

        long chunkKey = ChunkPos.toLong(x >> 4, z >> 4);
        long blockKey = pack(x, y, z);

        synchronized (lock) {
            LongOpenHashSet blocksInChunk = chunkBlocks.get(chunkKey);

            if (is) {
                if (blocksInChunk == null) {
                    blocksInChunk = new LongOpenHashSet();
                    chunkBlocks.put(chunkKey, blocksInChunk);
                }
                if (blocksInChunk.add(blockKey)) totalBlocks++;
            } else if (blocksInChunk != null && blocksInChunk.remove(blockKey)) {
                totalBlocks--;
                if (blocksInChunk.isEmpty()) chunkBlocks.remove(chunkKey);
            }

            dirty = true;
        }
    }

    // Clustering

    private void recompute() {
        Long2ObjectMap<LongOpenHashSet> snapshot;
        synchronized (lock) {
            snapshot = new Long2ObjectOpenHashMap<>(chunkBlocks.size());
            for (Long2ObjectMap.Entry<LongOpenHashSet> entry : chunkBlocks.long2ObjectEntrySet()) {
                snapshot.put(entry.getLongKey(), new LongOpenHashSet(entry.getValue()));
            }
            dirty = false;
        }

        int radius = gap.get();
        int maxSize = maxClusterSize.get();
        long now = System.currentTimeMillis();
        Long2ObjectMap<Track> prev = previous;

        LongOpenHashSet visited = new LongOpenHashSet();
        LongArrayList stack = new LongArrayList();
        Long2ObjectMap<Track> next = new Long2ObjectOpenHashMap<>();
        List<Cluster> out = new ArrayList<>();

        for (LongOpenHashSet set : snapshot.values()) {
            LongIterator it = set.iterator();

            while (it.hasNext()) {
                long start = it.nextLong();
                if (!visited.add(start)) continue;

                stack.clear();
                stack.add(start);

                int size = 0;
                double sumX = 0, sumY = 0, sumZ = 0;
                int minX = Integer.MAX_VALUE, minYv = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
                int maxX = Integer.MIN_VALUE, maxYv = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
                long anchor = start;
                Track best = null;

                while (!stack.isEmpty()) {
                    long cur = stack.removeLong(stack.size() - 1);
                    int x = unpackX(cur);
                    int y = unpackY(cur);
                    int z = unpackZ(cur);

                    size++;
                    sumX += x;
                    sumY += y;
                    sumZ += z;
                    if (x < minX) minX = x;
                    if (y < minYv) minYv = y;
                    if (z < minZ) minZ = z;
                    if (x > maxX) maxX = x;
                    if (y > maxYv) maxYv = y;
                    if (z > maxZ) maxZ = z;
                    if (cur < anchor) anchor = cur;

                    Track track = prev.get(cur);
                    if (track != null && (best == null || track.size() > best.size())) best = track;

                    for (int dx = -radius; dx <= radius; dx++) {
                        for (int dy = -radius; dy <= radius; dy++) {
                            for (int dz = -radius; dz <= radius; dz++) {
                                if (dx == 0 && dy == 0 && dz == 0) continue;

                                int nx = x + dx;
                                int ny = y + dy;
                                int nz = z + dz;
                                long neighbour = pack(nx, ny, nz);
                                if (visited.contains(neighbour)) continue;

                                LongOpenHashSet chunkSet = snapshot.get(ChunkPos.toLong(nx >> 4, nz >> 4));
                                if (chunkSet == null || !chunkSet.contains(neighbour)) continue;

                                visited.add(neighbour);
                                stack.add(neighbour);
                            }
                        }
                    }
                }

                if (size < 3) continue;

                // A cluster that is bigger than the last time we saw it has grown. Clusters seen for the first
                // time are not counted as growing.
                long lastGrow = 0;
                if (best != null) lastGrow = size > best.size() ? now : best.lastGrow();

                next.put(anchor, new Track(size, lastGrow));

                if (size <= maxSize) {
                    out.add(new Cluster(size,
                        sumX / size + 0.5, sumY / size + 0.5, sumZ / size + 0.5,
                        minX, minYv, minZ, maxX, maxYv, maxZ, lastGrow));
                }
            }
        }

        previous = next;
        clusters = out;
    }

    // Main thread housekeeping

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.world == null || mc.player == null) return;

        if (mc.world != lastWorld) {
            reset();
            lastWorld = mc.world;
            rescanAll();
            return;
        }

        if (capHit && !capWarned) {
            warning("Reached the max-total-blocks cap, some chunks are being skipped. Raise the cap or narrow the Y range.");
            capWarned = true;
        }

        if (++ticks % updateInterval.get() != 0) return;

        prune();

        if (dirty && busy.compareAndSet(false, true)) {
            MeteorExecutor.execute(() -> {
                try {
                    recompute();
                } finally {
                    busy.set(false);
                }
            });
        }

        refreshDrawLists();
    }

    /** Forgets chunks the client has unloaded. */
    private void prune() {
        synchronized (lock) {
            var iterator = chunkBlocks.long2ObjectEntrySet().iterator();

            while (iterator.hasNext()) {
                Long2ObjectMap.Entry<LongOpenHashSet> entry = iterator.next();
                long key = entry.getLongKey();

                if (!mc.world.getChunkManager().isChunkLoaded(chunkX(key), chunkZ(key))) {
                    totalBlocks -= entry.getValue().size();
                    iterator.remove();
                    dirty = true;
                }
            }

            specials.keySet().removeIf(k -> !mc.world.getChunkManager().isChunkLoaded(chunkX(k), chunkZ(k)));
        }
    }

    private void refreshDrawLists() {
        refreshSpecialMarks();

        List<Cluster> all = clusters;
        long now = System.currentTimeMillis();
        long windowMs = growthWindow.get() * 1000L;

        double px = mc.player.getX();
        double py = mc.player.getY();
        double pz = mc.player.getZ();
        double maxDist = maxDistance.get();
        double maxDistSq = maxDist * maxDist;

        // Clusters to draw: big enough, close enough and (optionally) growing, nearest first.
        List<Cluster> visible = new ArrayList<>();
        for (Cluster cluster : all) {
            if (cluster.size() < minClusterSize.get()) continue;
            if (growingOnly.get() && !cluster.growing(now, windowMs)) continue;
            if (distSq(cluster, px, py, pz) > maxDistSq) continue;
            visible.add(cluster);
        }

        visible.sort(Comparator.comparingDouble(c -> distSq(c, px, py, pz)));
        if (visible.size() > maxTracers.get()) visible = new ArrayList<>(visible.subList(0, maxTracers.get()));
        drawClusters = visible;

        // Chunk finder: group big clusters by the chunk their center is in.
        if (!chunkFinder.get()) {
            marks = List.of();
            return;
        }

        Long2ObjectMap<int[]> perChunk = new Long2ObjectOpenHashMap<>();
        for (Cluster cluster : all) {
            if (cluster.size() < bigClusterSize.get()) continue;

            int cx = (int) Math.floor(cluster.x()) >> 4;
            int cz = (int) Math.floor(cluster.z()) >> 4;
            int[] data = perChunk.computeIfAbsent(ChunkPos.toLong(cx, cz), k -> new int[]{0, Integer.MAX_VALUE, Integer.MIN_VALUE});

            data[0]++;
            data[1] = Math.min(data[1], cluster.minY());
            data[2] = Math.max(data[2], cluster.maxY());
        }

        List<ChunkMark> newMarks = new ArrayList<>();
        for (Long2ObjectMap.Entry<int[]> entry : perChunk.long2ObjectEntrySet()) {
            int[] data = entry.getValue();
            if (data[0] < chunkClusterCount.get()) continue;

            long key = entry.getLongKey();
            int cx = chunkX(key);
            int cz = chunkZ(key);
            newMarks.add(new ChunkMark(cx, cz, data[0], data[1], data[2]));

            if (announced.add(key) && chunkNotifications.get()) {
                info("Chunk (highlight)%s, %s(default) has (highlight)%s(default) big clusters, around X %s Z %s.",
                    String.valueOf(cx), String.valueOf(cz), String.valueOf(data[0]),
                    String.valueOf(cx * 16 + 8), String.valueOf(cz * 16 + 8));
            }
        }

        marks = newMarks;
    }

    /** Builds the list of chunks that have a capped shaft or an egg, and announces new ones. */
    private void refreshSpecialMarks() {
        List<SpecialMark> list = new ArrayList<>();

        synchronized (lock) {
            for (Long2ObjectMap.Entry<Special> entry : specials.long2ObjectEntrySet()) {
                Special special = entry.getValue();
                long key = entry.getLongKey();
                list.add(new SpecialMark(chunkX(key), chunkZ(key), special.shafts(), special.eggs(), special.minY(), special.maxY()));
            }
        }

        for (SpecialMark mark : list) {
            long key = ChunkPos.toLong(mark.cx(), mark.cz());
            if (!announcedSpecial.add(key) || !chunkNotifications.get()) continue;

            String what;
            if (mark.shafts() > 0 && mark.eggs() > 0) what = "capped shaft x" + mark.shafts() + " and egg x" + mark.eggs();
            else if (mark.shafts() > 0) what = "capped shaft x" + mark.shafts();
            else what = "egg x" + mark.eggs();

            info("Chunk (highlight)%s, %s(default) around X %s Z %s: %s.",
                String.valueOf(mark.cx()), String.valueOf(mark.cz()),
                String.valueOf(mark.cx() * 16 + 8), String.valueOf(mark.cz() * 16 + 8), what);
        }

        specialMarks = list;
    }

    // Block positions are packed into one long the same way vanilla does (26 bits x, 26 bits z, 12 bits y).
    private static long pack(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFFL);
    }

    private static int unpackX(long packed) {
        return (int) (packed >> 38);
    }

    private static int unpackY(long packed) {
        return (int) (packed << 52 >> 52);
    }

    private static int unpackZ(long packed) {
        return (int) (packed << 26 >> 38);
    }

    // ChunkPos.toLong stores x in the low 32 bits and z in the high 32 bits.
    private static int chunkX(long key) {
        return (int) key;
    }

    private static int chunkZ(long key) {
        return (int) (key >> 32);
    }

    private static double distSq(Cluster c, double px, double py, double pz) {
        double dx = c.x() - px;
        double dy = c.y() - py;
        double dz = c.z() - pz;
        return dx * dx + dy * dy + dz * dz;
    }

    // Rendering

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.player == null) return;

        long now = System.currentTimeMillis();
        long windowMs = growthWindow.get() * 1000L;

        double fromX = RenderUtils.center.x;
        double fromY = RenderUtils.center.y;
        double fromZ = RenderUtils.center.z;

        for (Cluster cluster : drawClusters) {
            Color color = cluster.growing(now, windowMs) ? growingColor.get() : clusterColor.get();

            if (tracers.get()) {
                event.renderer.line(fromX, fromY, fromZ, cluster.x(), cluster.y(), cluster.z(), color);
            }

            if (boxes.get()) {
                event.renderer.box(
                    cluster.minX(), cluster.minY(), cluster.minZ(),
                    cluster.maxX() + 1, cluster.maxY() + 1, cluster.maxZ() + 1,
                    color, color, ShapeMode.Lines, 0
                );
            }
        }

        Color special = specialColor.get();
        for (SpecialMark mark : specialMarks) {
            double x1 = mark.cx() * 16.0;
            double z1 = mark.cz() * 16.0;

            event.renderer.box(x1, mark.minY(), z1, x1 + 16, mark.maxY() + 1, z1 + 16, special, special, ShapeMode.Both, 0);

            if (chunkTracers.get()) {
                double midY = (mark.minY() + mark.maxY() + 1) / 2.0;
                event.renderer.line(fromX, fromY, fromZ, x1 + 8, midY, z1 + 8, special);
            }
        }

        if (!chunkFinder.get()) return;

        Color mark = chunkColor.get();
        for (ChunkMark chunk : marks) {
            double x1 = chunk.cx() * 16.0;
            double z1 = chunk.cz() * 16.0;

            event.renderer.box(x1, chunk.minY(), z1, x1 + 16, chunk.maxY() + 1, z1 + 16, mark, mark, ShapeMode.Both, 0);

            if (chunkTracers.get()) {
                double midY = (chunk.minY() + chunk.maxY() + 1) / 2.0;
                event.renderer.line(fromX, fromY, fromZ, x1 + 8, midY, z1 + 8, mark);
            }
        }
    }
}
